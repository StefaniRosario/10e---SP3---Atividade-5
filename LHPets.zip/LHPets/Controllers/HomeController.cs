﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using LHPets.Models;

namespace LHPets.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {   
        //instâncias do tipo cliente
        Cliente cliente1 = new Cliente(01, "Stefani Rosario1", "222.222.222-00", "emailstefani1@gmail.com", "Morena1");
        Cliente cliente2 = new Cliente(02, "Stefani Rosario2", "222.222.222-02", "emailstefani2@gmail.com", "Morena2");
        Cliente cliente3 = new Cliente(03, "Stefani Rosario3", "222.222.222-03", "emailstefani3@gmail.com", "Morena3");
        Cliente cliente4 = new Cliente(04, "Stefani Rosario4", "222.222.222-04", "emailstefani4@gmail.com", "Morena4");
        Cliente cliente5 = new Cliente(05, "Stefani Rosario5", "222.222.222-05", "emailstefani5@gmail.com", "Morena5");
        
        //lista do tipo cliente e atribui os clientes
        List<Cliente> listaClientes = new List<Cliente>();
        listaClientes.Add(cliente1);
        listaClientes.Add(cliente2);
        listaClientes.Add(cliente3);
        listaClientes.Add(cliente4);
        listaClientes.Add(cliente5);

        ViewBag.listaClientes = listaClientes;



        //instâncias do tipo fornecedor
        Fornecedor fornecedor1 = new Fornecedor(01, "Interfill1", "00.000.000/0001-01", "emailfornecedor1@gmail.com");
        Fornecedor fornecedor2 = new Fornecedor(02, "Interfill2", "00.000.000/0001-02", "emailfornecedor2@gmail.com");
        Fornecedor fornecedor3 = new Fornecedor(03, "Interfill3", "00.000.000/0001-03", "emailfornecedor3@gmail.com");
        Fornecedor fornecedor4 = new Fornecedor(04, "Interfill4", "00.000.000/0001-04", "emailfornecedor4@gmail.com");
        Fornecedor fornecedor5 = new Fornecedor(05, "Interfill5", "00.000.000/0001-05", "emailfornecedor5@gmail.com");

        //lista do tipo fornecedor e atribui os fornecedores
        List<Fornecedor> listaFornecedores = new List<Fornecedor>();
        listaFornecedores.Add(fornecedor1);
        listaFornecedores.Add(fornecedor2);
        listaFornecedores.Add(fornecedor3);
        listaFornecedores.Add(fornecedor4);
        listaFornecedores.Add(fornecedor5);

        ViewBag.listaFornecedores = listaFornecedores;


        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
